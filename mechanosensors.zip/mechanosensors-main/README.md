
## Data

  * The static images are present in this repositoy (folder 'cropped_images'), as well as the obtained segmentation masks (folder 'new_masks'). The segmentation process is implemented on "pre_processing.py"
  * The folder 'videos' can be downloaded from the following link: https://drive.google.com/drive/folders/1d0MOzHKdnrv6gAbhlg8sOJOd3puwxmnR?usp=sharing
